# 内容说明

Implement of *SEMI-SUPERVISED CLASSIFICATION WITH GRAPH CONVOLUTIONAL NETWORKS*

# 文件说明

| 文件            | 说明                                 |
| --------------- | ------------------------------------ |
| MyNode.py       | 基于Cora数据集的节点分类             |
| node_classify   | 数据集文件夹                         |
| dataset_view.py | 查看数据集内容及大小（MyNode中也有） |







​																																							2020年8月26日    lc

